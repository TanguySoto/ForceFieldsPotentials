﻿using UnityEngine;

public class Position : MonoBehaviour {

	// rotation
	public Vector3 initialPos 	= new Vector3 (0.1f, 0.1f, 0.1f); // only used for the ship in case of retry
	public Vector3 pos 			= new Vector3(0,0,0);
}