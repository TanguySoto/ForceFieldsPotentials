﻿using UnityEngine;
using System.Collections;

/*
 * Project ISG : "Force Field Potentials"
 * UPMC 2017/2018
 * 
 * Nicolas BILLOD
 * Guillaume LORTHIOIR
 * Tanguy SOTO
 */

public class LevelInformations : MonoBehaviour {
	public int NB_BONUS;
	public int collectedBonus;

	public float EXPERT_TIME;
}
